const {readFile} = require('fs/promises')

/* exports.nombreFuncion = (parametros) => {

    return visualViewport;
} */

//1.LEER UN FICHERO DE FORMA ASÍNCRONA
//Lee de forma asincrona el fichero JSON
exports.load = async (citiesFilename) => {
    const lector = await readFile(citiesFilename);
    return JSON.parse(lector);
}

//2.OBTENER INFROMACION SOBRE TEMPERATURAS
//Obtiene la temperatura de todas las ciudades y devuelve la temperatura mas alta 
//devuelve un numero
exports.max_temp = (cities) => {
    const temperaturas = cities.map(city => city.main.temp || -Infinity);
    return Math.max(... temperaturas);
}

//Obtiene la temperatura de todas las ciudades y devuelve la temperatura mas baja
//devuelve un numero
exports.min_temp = (cities) => {
    const temperaturas = cities.map(city => city.main.temp || +Infinity);
    return Math.min(... temperaturas);
}

//Obtiene la temperatura de todas las ciudades y devuelve la temperatura de la temperatura minima mas alta
//devuelve un numero
exports.max_temp_min = (cities) => {
    const temperaturasmaxima = cities.map(city => city.main.temp_min || -Infinity);
    return Math.max(... temperaturasmaxima);
}

//Obtiene la temperatura de todas las ciudades y devuelve la temperatura de la temperatura maxima mas baja
//devuelve un numero 
exports.min_temp_max = (cities) => {
    const temperaturasminima = cities.map(city => city.main.temp_max || +Infinity);
    return Math.min(... temperaturasminima);
}

//Obtiene la temperatura de todas las ciudades y devuelve la temperatura media
//devuelve un numero
exports.average_temp = (cities) => {
    const sumaTemperaturas = cities.reduce((tmp, city) =>
        tmp= tmp + city.main.temp || 0, 0);
    return sumaTemperaturas/cities.length;
}

//Devuelve un array con el nombre de las ciudades cuya temperatura supera la temperatura media 
//Devuelve un array
exports.warmer_average_temp = (cities) => {
    const meanTemp = this.average_temp(cities);
    const citiesFinal = cities.filter(city => city.main.temp > meanTemp);
    return citiesFinal.map(city => city.name);
}

//3.FILTRAR POR POSICION GEOGRAFICA
//Devuelve el nobre de la ciudad situada mas al norte
exports.max_north = (cities) => {
    const lats = cities.map(city => city.coord.lat || -Infinity);
    const lat = Math.max(... lats);
    return cities.find(city => city.coord.lat == lat).name;
}

//Devuelve el nombre de la ciudad mas al sur
//Devuelve un string
exports.max_south = (cities) => {
    const lats = cities.map(city => city.coord.lat || +Infinity);
    const lat = Math.min(... lats);
    return cities.find(city => city.coord.lat == lat).name;
}

//Calcula el centro de gravedad de todas las ciudades usando latitud y longitud. El centro de gravedad se calcula como la media de las latitudes y longitudes.
//Devuelve un objeto con dos propiedades, lat y lon, que contienen las coordenadas del centro de gravedad
exports.gravity_center = (cities) => {
    const sumaCoordenadas = cities.reduce((coords, city) => {
        const newLongitud = coords.lon + city.coord.lon;
        const newLatitud = coords.lat + city.coord.lat;
        return {lon: newLongitud, lat: newLatitud};
    }, {lon:0, lat:0})
    return { lon: sumaCoordenadas.lon/cities.length, lat: sumaCoordenadas.lat/cities.length};
}

//Devuelve el nombre de la ciudad mas cercana al centro de gavedad
//
exports.closest_GC = (cities) => {
    const centroGravedad = this.gravity_center(cities);
    let minimaDistancia = Infinity;
    let name;
    for (const city of cities) {
        const distancia = Math.sqrt(Math.pow(centroGravedad.lat - city.coord.lat, 2) + Math.pow(centroGravedad.lon - city.coord.lon, 2));
        if (distancia < minimaDistancia) {
            name = city.name;
            minimaDistancia = distancia;
        }
    }
    return name;
}